import { useMoralis, useNativeBalance } from "react-moralis";

function NativeBalance(props) {
  const { data: balance } = useNativeBalance(props);
  const { account, isAuthenticated } = useMoralis();

  if (!account || !isAuthenticated) return null;

  return <div style={{ textAlign: "center", color:'rgba(250,250,250,0.9)', whiteSpace: "nowrap" }}>{balance.formatted}</div>;
}

export default NativeBalance;
